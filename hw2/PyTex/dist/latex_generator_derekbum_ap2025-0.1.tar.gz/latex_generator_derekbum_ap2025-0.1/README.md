# Latex generator

This package allows user to generate LaTeX with:
1) A table by two-dimensional table.
2) A picture using provided file.
